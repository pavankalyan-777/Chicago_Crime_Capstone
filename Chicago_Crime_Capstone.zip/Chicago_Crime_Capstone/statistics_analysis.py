import pandas as pd
import numpy as np
import os

print("CASE 3: STATISTICAL ANALYSIS")

#1.LOAD CLEANED DATA
file_path = os.path.join(
    "output",
    "cleaned_chicago_crime.csv"
)

data = pd.read_csv(file_path)

print("\n Cleaned dataset loaded successfully.")
print("Shape:", data.shape)



#2.CRIME COUNT BY HOUR
print("\n CRIME COUNT BY HOUR")


data["hour"] = pd.to_datetime(data["date"]).dt.hour

crime_by_hour = (
    data.groupby("hour")
    .size()
)

print(crime_by_hour)


#3.COMMUNITY AREA CRIME COUNTS
print("\n COMMUNITY AREA CRIME COUNTS")

community_counts = (
    data.groupby("community_code")
    .size()
    .sort_values()
)

print(community_counts)



#4.IQR OUTLIER ANALYSIS
print("\n IQR OUTLIER ANALYSIS")

Q1 = community_counts.quantile(0.25)
Q3 = community_counts.quantile(0.75)

IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

print("Q1 =", Q1)
print("Q3 =", Q3)
print("IQR =", IQR)
print("Lower bound =", lower_bound)
print("Upper bound =", upper_bound)

outliers = community_counts[
    (community_counts < lower_bound) |
    (community_counts > upper_bound)
]

print("\n Outlier community areas:")

if len(outliers) == 0:
    print("No outliers found.")
else:
    print(outliers)

#5.CORRELATION ANALYSIS
print("\n CORRELATION MATRIX")

numeric_columns = data.select_dtypes(
    include=np.number
).columns

correlation_matrix = data[
    numeric_columns
].corr()

print(correlation_matrix)

#6.SAVE RESULTS
os.makedirs("charts", exist_ok=True)

crime_by_hour.to_csv(
    "charts/crime_by_hour.csv"
)

community_counts.to_csv(
    "charts/community_crime_counts.csv"
)

correlation_matrix.to_csv(
    "charts/correlation_matrix.csv"
)

if len(outliers) > 0:
    outliers.to_csv(
        "charts/community_outliers.csv"
    )

print("\n Case 3 Completed")
print("Statistical analysis files saved in charts folder.")
