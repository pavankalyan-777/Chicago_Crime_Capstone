import pandas as pd
import os


print("CASE 2: CRIME DATA ANALYSIS")

#1.LOAD CLEANED DATA

file_path = os.path.join(
    "output",
    "cleaned_chicago_crime.csv")

data=pd.read_csv(file_path)

print("\n Dataset loaded successfuly.")
print("Rows:", len(data))
print("Columns:", len(data.columns))

#2.CRIME COUNT BY YEAR
print("\n CRIME COUNT BY YEAR ")

crime_by_year = data.groupby("year").size()
print(crime_by_year)

#3.TOP 10 CRIME CATEGORIES
print("\n CRIME COUNT BY YEAR ")
top_crimes = (
    data["primary_type"]
    .value_counts()
    .head(10)
    )
crime_percentage = (top_crimes / len(data) * 100).round(2)
top_crimes_table = pd.DataFrame({
    "crime_count": top_crimes,
    "percentage": crime_percentage})
print(top_crimes_table)

#OVERALL ARREST RATE
print("\n OVERALL ARREST RATE ")
arrest_rate = data["arrest"].mean() * 100

print("Overall arrest rate:",round(arrest_rate, 2), "%")

#ARREST RATE BY YEAR
print("\n ARREST RATE BY YEAR")
arrest_by_year = (data.groupby("year")["arrest"].mean() * 100)
print(arrest_by_year.round(2))

#TOP 10 COMMUNITY AREAS
print("\n CRIME COUNT BY YEAR")
top_communities = (
    data["primary_type"]
    .value_counts()
    .head(10)
    )
print(top_communities)

#SAVE ANALYSIS RESULTS
os.makedirs("charts", exist_ok=True)
crime_by_year.to_csv("charts/crime_by_year.csv")
top_crimes_table.to_csv("charts/top_10_crime_categories.csv")
arrest_by_year.round(2).to_csv("charts/arrest_rate_by_year.csv")
top_communities.to_csv("charts/top_10-_community_areas.csv")

print("\n CASE 2 COMPLETED")
print("Analysis files saved in the charts folder.")















