import pandas as pd
import sqlite3
import os

print("CASE 4: SQL DATABASE AND REPORTING")

#1.LOAD CLEANED DATA
csv_file = os.path.join(
    "output",
    "cleaned_chicago_crime.csv"
)

df = pd.read_csv(csv_file)

print("\nCleaned dataset loaded.")
print("Rows:", len(df))

#2.CREATE SQLITE DATABASE
database_file = os.path.join(
    "output",
    "chicago_crime.db"
)

connection = sqlite3.connect(database_file)

print("\nSQLite database created.")


#3.CREATE TABLE
df.to_sql(
    "crime_data",
    connection,
    if_exists="replace",
    index=False
)

print("Table 'crime_data' created successfully.")

#4.CRIME COUNT BY YEAR
print("\n CRIME COUNT BY YEAR")

query1 = """
SELECT
    year,
    COUNT(*) AS crime_count
FROM crime_data
GROUP BY year
ORDER BY year;
"""

crime_by_year = pd.read_sql_query(
    query1,
    connection
)

print(crime_by_year)

#5.TOP 5 CRIME TYPES
print("\n TOP 5 CRIME TYPES")

query2 = """
SELECT
    primary_type,
    COUNT(*) AS crime_count,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*) FROM crime_data),
        2
    ) AS percentage
FROM crime_data
GROUP BY primary_type
ORDER BY crime_count DESC
LIMIT 5;
"""

top_crimes = pd.read_sql_query(
    query2,
    connection
)

print(top_crimes)


#6.ARRESTS BY YEAR
print("\n ARRESTS BY YEAR")

query3 = """
SELECT
    year,
    SUM(CASE WHEN arrest = 1 THEN 1 ELSE 0 END)
        AS arrest_count,
    ROUND(
        AVG(CASE WHEN arrest = 1 THEN 1.0 ELSE 0.0 END)
        * 100,
        2
    ) AS arrest_rate_percent
FROM crime_data
GROUP BY year
ORDER BY year;
"""

arrests_by_year = pd.read_sql_query(
    query3,
    connection
)

print(arrests_by_year)

#7.TOP 10 COMMUNITY AREAS
print("\n TOP 10 COMMUNITY AREAS")

query4 = """
SELECT
    community_code,
    COUNT(*) AS crime_count
FROM crime_data
WHERE community_code IS NOT NULL
GROUP BY community_code
ORDER BY crime_count DESC
LIMIT 10;
"""

top_communities = pd.read_sql_query(
    query4,
    connection
)

print(top_communities)

#8.CREATE SQL VIEWS
connection.execute("""
CREATE VIEW IF NOT EXISTS crime_by_year AS
SELECT
    year,
    COUNT(*) AS crime_count
FROM crime_data
GROUP BY year
ORDER BY year;
""")


connection.execute("""
CREATE VIEW IF NOT EXISTS top_crime_types AS
SELECT
    primary_type,
    COUNT(*) AS crime_count
FROM crime_data
GROUP BY primary_type
ORDER BY crime_count DESC;
""")


connection.execute("""
CREATE VIEW IF NOT EXISTS arrests_by_year AS
SELECT
    year,
    SUM(
        CASE
            WHEN arrest = 1 THEN 1
            ELSE 0
        END
    ) AS arrest_count
FROM crime_data
GROUP BY year
ORDER BY year;
""")


connection.commit()

print("\nSQL views created successfully.")

#9.SAVE SQL RESULTS
os.makedirs("charts", exist_ok=True)

crime_by_year.to_csv(
    "charts/sql_crime_by_year.csv",
    index=False
)

top_crimes.to_csv(
    "charts/sql_top_crime_types.csv",
    index=False
)

arrests_by_year.to_csv(
    "charts/sql_arrests_by_year.csv",
    index=False
)

top_communities.to_csv(
    "charts/sql_top_communities.csv",
    index=False
)

#10.CLOSE DATABASE
connection.close()

print("\n Database saved to:")
print(database_file)

print("\n CASE 4 COMPLETED")
