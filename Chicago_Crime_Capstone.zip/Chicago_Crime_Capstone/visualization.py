import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns



#CASE_5.DATA VISUALIZATION
print("CASE 5: DATA VISUALIZATION")

#1.SETUP PATHS
base_dir = os.path.dirname(os.path.abspath(__file__))

data_file = os.path.join(
    base_dir,
    "output",
    "cleaned_chicago_crime.csv"
)

charts_folder = os.path.join(
    base_dir,
    "charts"
)

os.makedirs(charts_folder, exist_ok=True)

#2.LOAD CLEANED DATA
data = pd.read_csv(data_file)

print("\nCleaned dataset loaded successfully.")
print("Rows:", len(data))
print("Columns:", len(data.columns))


#3.PREPARE DATE AND TIME FEATURES
if "date" in data.columns:

    data["date"] = pd.to_datetime(
        data["date"],
        errors="coerce"
    )

elif "Date" in data.columns:

    data["Date"] = pd.to_datetime(
        df["Date"],
        errors="coerce"
    )

    data["date"] = data["Date"]

else:

    raise ValueError(
        "Date column was not found in the cleaned dataset."
    )


#Create year if it does not already exist
if "year" not in data.columns:
    data["year"] = data["date"].dt.year


#Create month if it does not already exist
if "month" not in data.columns:
    data["month"] = data["date"].dt.month


#Create hour if it does not already exist
if "hour" not in data.columns:
    data["hour"] = data["date"].dt.hour


#Create day of week
if "day_of_week" not in data.columns:

    data["day_of_week"] = (
        data["date"]
        .dt.day_name()
    )

#4.SET SEABORN STYLE
sns.set_theme(
    style="whitegrid"
)

#1.CRIME COUNT BY YEAR
crime_by_year = (
    data.groupby("year")
    .size()
    .reset_index(name="crime_count")
    .sort_values("year")
)


plt.figure(figsize=(12, 7))

sns.lineplot(
    data=crime_by_year,
    x="year",
    y="crime_count",
    marker="o"
)

plt.title(
    "Crime Count by Year",
    fontsize=16
)

plt.xlabel("Year")
plt.ylabel("Crime Count")

plt.xticks(
    crime_by_year["year"]
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "crime_count_by_year.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: crime_count_by_year.png")

#2.TOP 10 CRIME CATEGORIES
top_categories = (
    data["primary_type"]
    .value_counts()
    .head(10)
    .reset_index()
)

top_categories.columns = [
    "primary_type",
    "crime_count"
]

top_categories["percentage"] = (
    top_categories["crime_count"]
    / len(data)
    * 100
)


#Reverse order for horizontal bar chart
category_chart = (
    top_categories
    .sort_values(
        "crime_count",
        ascending=True
    )
)


plt.figure(figsize=(12, 7))

sns.barplot(
    data=category_chart,
    x="crime_count",
    y="primary_type"
)

plt.title(
    "Top 10 Crime Categories",
    fontsize=16
)

plt.xlabel("Crime Count")
plt.ylabel("Crime Type")

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "top_10_crime_categories.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: top_10_crime_categories.png")

#3.ARREST COUNT BY YEAR
arrests_by_year = (
    data.groupby("year")
    .agg(
        arrest_count=("arrest", "sum"),
        crime_count=("arrest", "count")
    )
    .reset_index()
    .sort_values("year")
)


arrests_by_year["arrest_rate"] = (
    arrests_by_year["arrest_count"]
    / arrests_by_year["crime_count"]
    * 100
)


plt.figure(figsize=(12, 7))

sns.lineplot(
    data=arrests_by_year,
    x="year",
    y="arrest_count",
    marker="o"
)

plt.title(
    "Arrest Count by Year",
    fontsize=16
)

plt.xlabel("Year")
plt.ylabel("Arrest Count")

plt.xticks(
    arrests_by_year["year"]
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "arrest_count_by_year.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: arrest_count_by_year.png")



#4.TOP 10 COMMUNITY AREAS
top_communities = (
    data.groupby("community_code")
    .size()
    .reset_index(name="crime_count")
    .sort_values(
        "crime_count",
        ascending=False
    )
    .head(10)
)


#Remove missing community codes
top_communities = top_communities.dropna(
    subset=["community_code"]
)


#Reverse order so highest appears at top
community_chart = (
    top_communities
    .sort_values(
        "crime_count",
        ascending=True
    )
)


plt.figure(figsize=(12, 7))

sns.barplot(
    data=community_chart,
    x="crime_count",
    y=community_chart["community_code"].astype(str)
)

plt.title(
    "Top 10 Community Areas",
    fontsize=16
)

plt.xlabel("Crime Count")
plt.ylabel("Community Code")

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "top_10_community_areas.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: top_10_community_areas.png")


#5.CRIME INTENSITY BY HOUR
crimes_by_hour = (
    data.groupby("hour")
    .size()
    .reindex(
        range(24),
        fill_value=0
    )
    .reset_index(name="crime_count")
)


plt.figure(figsize=(12, 7))

sns.lineplot(
    data=crimes_by_hour,
    x="hour",
    y="crime_count",
    marker="o"
)

plt.title(
    "Crime Intensity by Hour",
    fontsize=16
)

plt.xlabel("Hour of Day")
plt.ylabel("Crime Count")

plt.xticks(
    range(24)
)

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "crime_intensity_by_hour.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: crime_intensity_by_hour.png")


#6.CRIME BY MONTH AND DAY OF WEEK
day_order = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
]


month_order = list(range(1, 13))


crime_month_day = pd.pivot_table(
    data,
    values="id",
    index="month",
    columns="day_of_week",
    aggfunc="count",
    observed=False,
    fill_value=0
)


#Make sure all months are present
crime_month_day = (
    crime_month_day
    .reindex(month_order, fill_value=0)
)


#Make sure all days are present and correctly ordered
crime_month_day = (
    crime_month_day
    .reindex(
        columns=day_order,
        fill_value=0
    )
)


plt.figure(figsize=(12, 8))

sns.heatmap(
    crime_month_day,
    annot=True,
    fmt="g",
    cmap="YlOrRd",
    linewidths=0.5
)

plt.title(
    "Crime Frequency by Month and Day of Week",
    fontsize=16
)

plt.xlabel("Day of Week")
plt.ylabel("Month")

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "crime_by_month_day.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()

print("Created: crime_by_month_day.png")

#7.COMMUNITY AREA OUTLIER ANALYSIS
community_counts = (
    data.groupby("community_code")
    .size()
    .reset_index(name="crime_count")
    .dropna(
        subset=["community_code"]
    )
)


#Calculate IQR
Q1 = community_counts[
    "crime_count"
].quantile(0.25)

Q3 = community_counts[
    "crime_count"
].quantile(0.75)

IQR = Q3 - Q1

lower_limit = Q1 - (1.5 * IQR)

upper_limit = Q3 + (1.5 * IQR)


#Identify outliers
outliers = community_counts[
    (
        community_counts["crime_count"]
        < lower_limit
    )
    |
    (
        community_counts["crime_count"]
        > upper_limit
    )
]


plt.figure(figsize=(12, 7))

sns.boxplot(
    y=community_counts["crime_count"]
)

plt.title(
    "Community Area Outlier Analysis",
    fontsize=16
)

plt.ylabel("Crime Count")

plt.tight_layout()

plt.savefig(
    os.path.join(
        charts_folder,
        "community_area_boxplot.png"
    ),
    dpi=150,
    bbox_inches="tight"
)

plt.close()


print("Created: community_area_boxplot.png")

print("\n Outlier community areas:")

print(
    outliers
    .set_index("community_code")[
        ["crime_count"]
    ]
)

#8.CORRELATION HEATMAP
print("\n Creating correlation heatmap")

#Only these five columns
correlation_columns=[
    "year",
    "month",
    "hour",
    "arrest",
    "community_code"
    ]

#Select only required columns
correlation_data = data[
    correlation_columns
    ].copy()

#Remove rows with missing values
correlation_data = correlation_data.dropna()

#Create correlation matrix
correlaton_matrix = (
    correlation_data.corr()
    )
plt.figure(figsize=(10,7))

sns.heatmap(
    correlaton_matrix,
    annot=True,
    fmt=".2f",
    cmap="coolwarm",
    linewidths=0.5,
    square=True,
    vmin=-1,
    vmax=1
    )
plt.title("Crime Data Correlation Matrix")
plt.tight_layout()
plt.savefig(
    os.path.join(
        charts_folder,
        "correlation_heatmap.png"
        ),
    dpi=300,
    bbox_inches="tight"
    )
plt.close()
print("Created: correlation_heatmap.png")

#FINAL OUTPUT
print("CASE 5 COMPLETED")

print("\n All chart files saved in:")
print(charts_folder)

print("\n Charts created:")

print("1. crime_count_by_year.png")
print("2. top_10_crime_categories.png")
print("3. arrest_count_by_year.png")
print("4. top_10_community_areas.png")
print("5. crime_intensity_by_hour.png")
print("6. crime_by_month_day.png")
print("7. community_area_boxplot.png")
print("8. correlation_heatmap.png")

print("\n Visualization completed successfully.")
