import pandas as pd
import sqlite3
import os

print("CASE 4: SQL DATABASE AND REPORTING")

#1.LOAD CLEANED DATA
csv_file = os.path.join("output","cleaned_chicago_crime.csv")
df = pd.read_csv(csv_file)
print("\n Cleaned dataset loaded successfully.")
print("Rows:", len(df))
print("columns:", len(df.columns))

#2.CREATE SQLITE DATABASE
database_file = os.path.join("output","chicago_crime.db")

connection = sqlite3.connect(database_file)
print("\n SQLite database connected successfully.")

#3.CREATE CRIME TABLE
df.to_sql("crime_data",
          connection,
          if_exists="replace",
          index=False
          )

print("Table 'crime_data' created successfully.")

#CRIME COUNT PER YEAR
print("\n CRIME COUNT PER YEAR")
query = """
SELECT
year,
COUNT(*) AS crime_count
FROM crime_data
GROUP BY year
ORDER BY year;
"""

crime_by_year = pd.read_sql_query(query,connection)
print(crime_by_year)

#TOP 5 CRIME TYPES AND PERCENTAGE
print("\n TOP 5 CRIME TYPES")
query = """
SELECT
primary_type,
COUNT(*) AS crime_count,
ROUND(
COUNT(*) * 100.0 /
(SELECT COUNT(*) FROM
crime_data),
2
) AS percentage
FROM crime_data
GROUP BY primary_type
ORDER BY crime_count DESC
LIMIT 5;
"""

top_crimes = pd.read_sql_query(query,connection)
print(top_crimes)

#ARREST COUNT PER YEAR
print("\n ARREST COUNT PER YEAR")
query = """
SELECT
year,
SUM(
CASE
WHEN arrest = 1 THEN 1
ELSE 0
END
) AS arrest_count
FROM crime_data
GROUP BY year
ORDER BY year;
"""

arrests_by_year = pd.read_sql_query(
    query,
    connection
    )
print(arrests_by_year)

#TOP 10 COMMUNITY AREAS
print("\n TOP 10 COMMUNITY AREAS")
query = """
SELECT
community_code,
COUNT(*) AS crime_count
FROM crime_data
WHERE community_code IS NOT NULL
GROUP BY community_code
ORDER BY crime_count DESC
LIMIT 10;
"""

top_communities = pd.read_sql_query(query,connection)
print(top_communities)

#CREATE REQUIRED DATABASE VIEWS
print("\n CREATING DATABASE VIEWS")

#REMOVE OLD VIEWS IF THEY ALREADY EXIST
connection.execute("DROP VIEW IF EXISTS vw_crime_yearly")
connection.execute("DROP VIEW IF EXISTS vw_crime_by_category")
connection.execute("DROP VIEW IF EXISTS vw_arrests_yearly")

connection.execute("""
CREATE VIEW vw_crime_yearly AS
SELECT
year,
COUNT(*) AS crime_count
FROM crime_data
GROUP BY year
ORDER BY year;
""")

#CRIME CATEGORY VIEW
connection.execute("""
CREATE VIEW vw_crime_by_category AS
SELECT
primary_type,
COUNT(*) AS crime_count,
ROUND(
COUNT(*) * 100.0 /
(SELECT COUNT(*) FROM
crime_data),
2
) AS percentage
FROM crime_data
GROUP BY primary_type
ORDER BY crime_count DESC;
""")

#ARREST YEARLY VIEW
connection.execute("""
CREATE VIEW vw_arrests_yearly AS
SELECT
year,
SUM(
CASE
WHEN arrest = 1 THEN 1
ELSE 0
END
) AS arrest_count
FROM crime_data
GROUP BY year
ORDER BY year;
""")

connection.commit()
print("vw_crime_yearly created.")
print("vw_crime_by_category created.")
print("vw_arrests_yearly created.")

#READ SQL VIEWS INTO PANDAS
print("\n PANDAS INTEGRATION")

yearly_view = pd.read_sql_query(
    "SELECT * FROM vw_crime_by_category;",
    connection
    )
category_view = pd.read_sql_query(
    "SELECT * FROM vw_crime_by_category;",
    connection
    )
arrest_view = pd.read_sql_query(
    "SELECT * FROM vw_arrests_yearly;",
    connection
    )
print("\nYearly crime view:")
print(yearly_view)

print("\nCrime category view:")
print(category_view.head(10))

print("\nArrest yearly view:")
print(arrest_view)

# SAVE SQL RESULTS
charts_folder = "charts"
os.makedirs(
    charts_folder,
    exist_ok=True
    )
crime_by_year.to_csv(
    os.path.join(
        charts_folder,
        "sql_crime_by_year.csv"),
    index=False
    )
top_crimes.to_csv(
    os.path.join(
        charts_folder,
        "sql_top_crime_types.csv"
        ),
    index=False
    )
arrests_by_year.to_csv(
    os.path.join(
        charts_folder,
        "sql_arrests_by_year.csv"
        ),
    index=False
    )
top_communities.to_csv(
    os.path.join(
        charts_folder,
        "sql_top_communitys.csv"
        ),
    index=False
    )
yearly_view.to_csv(
    os.path.join(
        charts_folder,
        "sql_view_crime_yealy.csv"
        ),
    index=False
    )

category_view.to_csv(
    os.path.join(
        charts_folder,
        "sql_view_crime_by_category.csv"
        ),
    index=False
    )

arrest_view.to_csv(
    os.path.join(
        charts_folder,
        "sql_view_arrests_yearly.csv"
        ),
    index=False
    )

#CLOSE DATABSE
connection.close()
print("\nSQL results saved in charts folder.")
print("\nDatabase saved to:")
print(os.path.abspath(database_file))

#COMPLETED
print("CASE 4 COMPLETED")
print("\n SQL analysis and reporting completed successfuly.") 




















    
