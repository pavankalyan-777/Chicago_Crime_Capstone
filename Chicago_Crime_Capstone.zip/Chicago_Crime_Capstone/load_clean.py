import pandas as pd
import numpy as np
import os

#CHICAGO CRIME CAPSTONE PROJECT
print("CHICAGO CRIME CAPSTONE - LOAD AND CLEAN")

#LOAD DATASET
file_path =os.path.join("data","chicago_crime_dataset.csv")

data = pd.read_csv(file_path)

print("\n Dataset loaded successfuly.")
print("Rows:", data.shape[0])
print("Columns:",data.shape[1])

print("\n First 10 rows:")
print(data.head(10))

print("\n Schema and data types:")
data.info()


#STANDARDIZE COLUMN NAMES
data.columns =(
    data.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_",regex=False)
)
print("\n Column names standardized.")

#CONVER DATE COLUMN INTO DATETIME FORMAT
if "date" in data.columns:
    data["date"] = pd.to_datetime(
        data["date"],
        errors="coerce"
    )
    print("date column converted to datetime.")
else:
    print("date column not found.")

# HANDLE MISSING VALUES
print("\nMissing values before cleaning:")
missing_before = data.isnull().sum()

print(
    missing_before[missing_before > 0]
    )

#Remove columns having more than 50% missing values
missing_percentage = (
    data.isnull().mean() * 100
    )

columns_to_drop = missing_percentage[missing_percentage > 50].index.tolist()

if columns_to_drop:

    print("\nColumns with more than 50% missing values:")
    print(columns_to_drop)

    data = data.drop(columns=columns_to_drop)
else:
    print("\nNo columns have more than 50% missing values.")

#HANDLE KEY NUMERIC FIELDS
numeric_columns = [
    "id",
    "iucr_code",
    "beat_num",
    "district_code",
    "ward_no",
    "community_code",
    "fbi_code",
    "x_coordinate",
    "y_coordinate",
    "year",
    "latitude",
    "longitude"
    ]
for column in numeric_columns:
    if column in data.columns:
        data[column] =pd.to_numeric(
            data[column],
            errors="coerce"
            )

#HANDLE ARREST COLUMN
if "arrest" in data.columns:
    data["arrest"] =(
        data["arrest"]
        .astype(str)
        .str.strip()
        .str.lower()
        .map({
            "true":1,
            "false":0,
            "1":1,
            "0":0,
            "yes":1,
            "no":0
            })
        )
    data["arrest"] = data["arrest"].fillna(0).astype(int)

#STANDARDIZE CATEGORICAL COLUMNS
categorical_columns = [
    "primary_type",
    "description",
    "location_desc",
    "block"
    ]

for column in categorical_columns:
    if column in data.columns:
       data[column] = (
           data[column]
           .astype("string")
           .str.strip()
           )
       if column in [
           "primary_type",
           "description"
           ]:
           data[column] = (data[column].str.upper())

#GENERATE DATE FEATURES
if "date" in data.columns:
       data["year"] = data["date"].dt.year
       data["month"] = data["date"].dt.month
       data["day_of_week"] = (data["date"].dt.day_name())

       print("\nNew date features created:")
       print("Year")
       print("Month")
       print("Day_of_week")
       print("hour")

#9.HANDLE IMPORTANT MISSING VALUES
#9A. TEXT COLUMNS
text_columns=[
    "primary_type",
    "description",
    "location_desc",
    "blocation",
    "dat_of_week"
    ]
for column in text_columns:
    if column in data.columns:
        data[column] = (
            data[column]
            .fillna("UNKNOWN")
            )
#9B.NUMERIC COULMNS
numeric_missing_columns=[
    "community_code",
    "wait_no",
    "x_coordinate",
    "y_coordinate",
    "latitude",
    "longitude"
]
for coulmn in numeric_missing_columns:
    if column in data.columns:
#CONVERT TO NUMERIC
        data[column] = pd.to_numeic(
            data[column],
            errors="coerce"
            )
#CALCULATE MEDIUM
        median_value =data[column].median()
#FILL MISSING VALUES
        if pd.nota(median_value):
            data[column] = (
                data[column]
                .fillna(median_value)
                )
            
#REMOVE DUPLICATES
duplicate_count = data.duplicated().sum()
print("\n Duplicate rows:", duplicate_count)

data = data.drop_duplicates()

#CALCULATE MISSING VALUES USING NUMPY
missing_percentage =(
    data.isnull().mean() * 100
    )
print("\n Missing percentage by column:")
remaining_missing = (
    missing_percentage[
        missing_percentage > 0
        ]
    .round(2)
    )
if len(remaining_missing) >0:
    print(remaining_missing)
else:
    print("No missing alues remaining.")
    
#SAVE CLEANED DATA
output_folder = "output"
os.makedirs(
    output_folder,
    exist_ok=True
    )
output_file = os.path.join(
    output_folder,
    "cleaned_chicago_crime.csv"
    )
data.to_csv(
    output_file,
    index=False
    )

#FINAL INFROMATION
print("CASE 1 COMPLETED")

print("\n Cleaned dataset saved to:")
print(os.path.abspath(output_file))

print("\n Final shape:")

print(data.shape)

print("\n Final column:")

print(list(data.columns))

print("\n First 5 rows:")

print(data.head())
print("\n Data cleaning completed successfuly.")
                         
                                       

                                        
             
            











