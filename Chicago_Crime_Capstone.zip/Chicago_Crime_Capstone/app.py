from flask import Flask, render_template,send_from_directory
import pandas as pd
import os

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

#LOAD CLEANED DATA
data_file = os.path.join(
    BASE_DIR,
    "output",
    "cleaned_chicago_crime.csv"
    )
df = pd.read_csv(data_file)

#DASHBOARD ROUTE
@app.route("/")
def dashboard():
    

    #TOTAL CRIMES
    total_crimes = len(df)
    

    #TOTAL ARRESTS
    total_arrests = int(
        df["arrest"].sum()
    )

    #OVERALL ARREST RATE
    if total_crimes > 0:
        overall_arrest_rate = round(
            (total_arrests / total_crimes) * 100,
            2
        )
    else:
        overall_arrest_rate = 0
          
   #CRIME COUNT BY YEAR
    crime_by_year = (
        df.groupby("year")
        .size()
        .reset_index(name="crime_count")
        .sort_values("year")
        .to_dict("records")
    )
        

    #TO 10 CRIME CATEGORIES
    top_categories = (
        df["primary_type"]
        .value_counts()
        .head(10)
        .reset_index()
    )
    top_categories.columns = [
        "primary_type",
        "crime_count"
    ]
    top_categories["percentage"] = (
        top_categories["crime_count"]
        / total_crimes
        *100
    ).round(2)
        
    top_categories = (
        top_categories
        .to_dict("records")
    )
        

    #ARREST COUNT AND RATE BY YEAR
    arrests = (
        df.groupby("year")
        .agg(
            arrest_count=("arrest","sum"),
            crime_count=("arrest","count")
        )
        .reset_index()
        .sort_values("year")
    )

    arrests["arrest_rate"] = (
        arrests["arrest_count"]
        / arrests["crime_count"]
        * 100
    ).round(2)
    arrests = arrests.to_dict("records")

    #TOP 10 COMMUNITY AREAS
    communities = (
        df.groupby("community_code")
        .size()
        .reset_index(name="crime_count")
        .sort_values(
            "crime_count",
            ascending=False
        )
        .head(10)
        .to_dict("records")
    )        
        
    #RENDER DASHBOARD
    return render_template(
        "index.html",
        total_crimes=total_crimes,
        total_arrests=total_arrests,
        overall_arrest_rate=overall_arrest_rate,
        crime_by_year=crime_by_year,
        top_categories=top_categories,
        arrests=arrests,
        communities=communities
    )

#CHART FILE ROUTE
@app.route("/charts/<filename>")
def charts(filename):
    chart_folder = os.path.join(
        BASE_DIR,
        "charts"
    )
    return send_from_directory(
        chart_folder,
        filename
    )
#RUN FLASK APPLICATION
if __name__ == "__main__":
    print("=" * 60)
    print("CHICAGO CRIME ANALYTICS DASHBOARD")
    print("=" * 60)
    print("\nOpen your browser:")
    print("http://127.0.0.1:5000/")
    
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False,
        use_reloader=False
    )
        
    










